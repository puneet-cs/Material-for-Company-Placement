# University Management System
# OOPs, Functions, list comprehension, Git & Github, Cloud

# Step-1 : Install the streamlit library
# Streamlit is used to build frontend 
# pip install streamlit

# ERROR : pip is not recognized
# Environment variable need to setup

# Command to run this project
streamlit run main.py

# Stoping the running project
CTRL + C 